
function bannerAnimate() {    
    var timeline = new TimelineMax();
    var rough = new RoughEase.ease.config({ template: Power0.easeNone, strength: 1, points: 50, taper: "none", randomize: true, clamp: false});
    timeline.set([".logo", ".des", ".lozung", ".offer", ".btn_block", ".star", ".avto",
       ".bg3", ".txt4", ".txt3", ".bg2", ".txt2", ".txt1", ".laser", '.dealer', '.far'],{autoAlpha:0})

     .set(".wheel_cont_1", {scaleX:0.70, y:"-=0.5",x:"+=0.5",alpha:0.6})
     .set(".wheel_cont_2", {scaleX:0.4,y:"+=0.5", scaleY:0.75, alpha:0.6})
     .to('.bnr_wrap', 0.5, {autoAlpha:1})
     .from(".bg1", 0.5, {autoAlpha:0})
     .add('repeat')
     .to(".txt1", 0.8, {autoAlpha:1, delay:0.5})
     .to(".txt1", 0.5, {autoAlpha:0, delay:1, onComplete:lasar_Anim})
     .to(".txt2", 0.8, {autoAlpha:1})
     .to([".txt2",".laser1", ".bg1", ".far"], 0.5, {autoAlpha:0, delay:2})
     .to(".bg2", 0.8, {autoAlpha:1, onComplete:lN}, '-=0.5')

     .from(".sv", 3, {autoAlpha:0, ease:rough})
     .to(".txt3", 0.5, {autoAlpha:1}, '-=2.8')
     
     .to([".txt3", ".bg2", ".sv"], 0.5, {autoAlpha:0,delay:1}, '-=1')

     .to(".bg3", 0.5, {autoAlpha:1}, '-=1')
     .to(".avto", 0.5, {autoAlpha:1}, '-=0.5')
     .to(".txt4", 0.5, {autoAlpha:1}, '-=0.3')
     .to(".btn_block", 0.8, {autoAlpha:1})
     
 
     .add('3s-=0,5')

     .from(".avto", 1.5, {x:"+=240",y:"-=20",force3D: "auto", ease: Power3.easeOut},"3s-=0.5")
     .to([".wheel_1", ".wheel_2"], 1.5, {rotation:"-=720", ease: Power3.easeOut}, '3s-=0.5')
     .to(".txt4", 0.8, {y:"-=90", ease: Power2.easeOut}, '3s+=0.5')
     .to(".star", 0.5,{autoAlpha:1, scale:1.2}, '3s+=1.3')
     .from(".txt5", 0.5, {autoAlpha:0, x:'+=60'},"3s+=1.8")
     .to(".star",0.9, {autoAlpha:0, x:-280, scaleX:30},"3s+=1.8")
     .to(".lozung", 0.5,{autoAlpha:1},"3s+=1.8")
     
     

     .to(".lozung", 0.5, {autoAlpha:0, delay:2})
     .to(".offer", 0.5, {autoAlpha:1})
     .to([".txt5", ".bg3", ".offer",".avto"], 0.5,{autoAlpha:0, delay:2})
     .to(".des", 0.5, {autoAlpha:1})
     .to(".d1", 0.5, {autoAlpha:0, delay:1})
     .to(".d2", 0.5, {autoAlpha:1})
     .to(".d2", 0.5, {autoAlpha:0, delay:1})
     .to(".dealer", 0.5,{autoAlpha:1})
     .to(".dealer", 0.5,{autoAlpha:0, delay:2})
     .to(".logo", 0.5,{autoAlpha:1})
     // .to(".logo", 0.5,{autoAlpha:0, delay:2})
     // .call(function () {
       // timeline.seek('repeat');
     // });


function lasar_Anim(){
    TweenMax.to(".laser", 0.8,{autoAlpha:1});
    TweenMax.to(".l2", 0.8,{autoAlpha:1});
    TweenMax.from(".laser1", 0.5,{height:"100px"});

  
}

function lN(){
      TweenMax.set(".laser", {autoAlpha:0});
}
}

window.onload = bannerAnimate;